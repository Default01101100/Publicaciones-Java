
package jerarquiaHerencia;

public interface Periodicidad {
    String periodo = "Semanal";
    

    
}
