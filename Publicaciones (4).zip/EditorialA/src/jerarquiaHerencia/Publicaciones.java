
package jerarquiaHerencia;

public class Publicaciones {
    private String titulo;
    private double precio;
    private int noPag;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getNoPag() {
        return noPag;
    }

    public void setNoPag(int noPag) {
        this.noPag = noPag;
    }
    
    
}
