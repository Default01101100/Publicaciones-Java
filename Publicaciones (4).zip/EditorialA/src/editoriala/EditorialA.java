
package editoriala;

import vista.Bienvenida;

public class EditorialA {

    public static void main(String[] args) {
        // TODO code application logic here
        Bienvenida bi = new Bienvenida();
        bi.setVisible(true);
    }
    
}
